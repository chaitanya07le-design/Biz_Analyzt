# Tally Sync Workflows for Pucho Studio

12 automated workflows to sync Tally Prime data to BizAnalyzt backend API.

## Files

| # | Filename | Purpose | Schedule |
|---|----------|---------|----------|
| 01 | `01_Tally_Company_Sync.json` | Sync company info & trial balance | Daily at midnight |
| 02 | `02_Tally_Ledger_Sync.json` | Sync groups & ledgers | Every 4 hours |
| 03 | `03_Tally_Party_Sync.json` | Sync customers & suppliers | Every 4 hours |
| 04 | `04_Tally_Cash_Bank_Sync.json` | Sync cash & bank accounts | Hourly |
| 05 | `05_Tally_Sales_Voucher_Sync.json` | Sync sales vouchers & lines | Hourly |
| 06 | `06_Tally_Purchase_Voucher_Sync.json` | Sync purchase vouchers & lines | Hourly |
| 07 | `07_Tally_Receipt_Payment_Sync.json` | Sync receipt & payment vouchers | Hourly |
| 08 | `08_Tally_Adjustment_Voucher_Sync.json` | Sync journal, debit & credit notes | Hourly |
| 09 | `09_Tally_Inventory_Sync.json` | Sync item groups & inventory | Daily at 2 AM |
| 10 | `10_Tally_Outstanding_Sync.json` | Refresh aging reports cache | Hourly |
| 11 | `11_Tally_Dashboard_Refresh.json` | Refresh dashboard reports cache | Hourly |
| 12 | `12_Tally_Reconciliation.json` | Reconcile balances & clear cache | Daily at 2:30 AM |

## Import Instructions

### Step 1: Import Workflow
1. Open **Pucho Studio**: https://studio.pucho.ai
2. Click **+ New Flow** or go to existing project
3. Click **Import** button
4. Select one of the JSON files from this folder
5. Click **Import**

### Step 2: Configure Tally Connection
After import, each workflow requires configuration:

1. Find the **Ask Tally Template** step
2. Click the step to open settings
3. In the **Tally Connection** field:
   - Select existing Tally connection, OR
   - Click **+ Add New** to create new connection
4. Provide Tally connection details:
   - Host (e.g., `localhost` or IP address)
   - Port (default: `9000`)
5. Click **Save**

### Step 3: Verify Backend URL (Optional)
Default backend URL: `http://localhost:5001`

If your backend runs on different URL:
1. Find the **HTTP Request** step
2. Update the URL in the `url` field
3. Click **Save**

### Step 4: Test Workflow
1. Click **Test** button (top right)
2. Select **Test Trigger** or **Manual Trigger**
3. Verify the test completes successfully
4. Check backend logs for received data

### Step 5: Publish & Enable
1. Click **Publish** button (top right)
2. Toggle **Enable** switch to ON
3. Workflow will now run on schedule

## Template IDs Reference

| Template ID | Purpose |
|-------------|---------|
| 48 | Trial Balance |
| 8 | Ledger Balances |
| 149 | Customers |
| 150 | Suppliers |
| 58 | Cash/Bank Balances |
| 133 | Sales Vouchers |
| 137 | Purchase Vouchers |
| 93 | Receipts |
| 92 | Payments |
| 88 | Debit Notes |
| 59 | Credit Notes |
| 46 | Stock Summary |
| 144 | Closing Stock |
| 136 | Receivable Aging |
| 85 | Payable Aging |
| 50 | Cash/Bank Position |
| 91 | Profit & Loss |
| 76 | Stock Value |
| 90 | Bank Statement |

## Backend API Endpoints

| Endpoint | Method | Mode | Purpose |
|----------|--------|------|---------|
| `/api/sync/Companies` | POST | overwrite | Sync company list |
| `/api/sync/Groups` | POST | overwrite | Sync ledger groups |
| `/api/sync/Ledgers` | POST | overwrite | Sync ledgers |
| `/api/sync/Parties` | POST | overwrite/append | Sync parties |
| `/api/sync/BankAccounts` | POST | overwrite | Sync bank accounts |
| `/api/sync/CashAccounts` | POST | overwrite | Sync cash accounts |
| `/api/sync/Vouchers` | POST | append | Sync vouchers |
| `/api/sync/VoucherLines` | POST | append | Sync voucher lines |
| `/api/sync/ItemGroups` | POST | overwrite | Sync item groups |
| `/api/sync/Items` | POST | overwrite | Sync inventory items |
| `/api/cache` | DELETE | - | Clear all cache |
| `/api/cache?sheet=Vouchers` | DELETE | - | Clear voucher cache |

## Troubleshooting

### Workflow Import Fails
- Ensure file extension is `.json`
- Check file is not corrupted
- Try importing one workflow at a time

### Tally Connection Error
- Verify Tally Prime is running
- Check Tally HTTP Gateway is enabled:
  - F1 → Setup → Connectivity → Enable ODBC/HTTP
  - Default port: `9000`
- Verify firewall allows connection
- Test connection manually:
  ```bash
  curl http://localhost:9000
  ```

### Backend API Error
- Verify backend server is running on port 5001
- Check backend logs for errors
- Verify endpoint URL is correct
- Test endpoint manually:
  ```bash
  curl -X POST http://localhost:5001/api/sync/Companies \
    -H "Content-Type: application/json" \
    -d '{"mode":"overwrite","data":[]}'
  ```

### Workflow Not Running on Schedule
- Ensure workflow is **Published**
- Ensure workflow is **Enabled**
- Check schedule configuration matches expected format
- Verify timezone is correct (Asia/Kolkata)

## Schedule Summary

| Time | Workflows |
|------|-----------|
| 00:00 | 01 - Company Sync |
| 02:00 | 09 - Inventory Sync |
| 02:30 | 12 - Reconciliation |
| Hourly | 04, 05, 06, 07, 08, 10, 11 |
| Every 4 hours | 02, 03 |

## Notes

- All workflows use `@puchoaistudio/tool-tallyconnection` v2.3.4
- Backend URL hardcoded to `http://localhost:5001`
- Tally connection must be configured after import
- Some workflows use `continueOnFailure: true` for resilience
- Cache refresh workflows (10, 11, 12) use DELETE requests

## Support

For issues or questions:
- Pucho Documentation: https://pucho.ai/documentation
- Tally Integration Help: https://help.tallysolutions.com
- Backend API Issues: Check backend logs
